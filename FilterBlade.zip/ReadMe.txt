You've added and downloaded some custom sounds for you filter. Those sound files need to be placed in the same folder as your filter file.

This is a list of all used custom sounds:
- Veskara_6veryvaluable.mp3
- Veskara_1maybevaluable.mp3
- Veskara_3uniques.mp3
- Veskara_2currency.mp3
- Veskara_12leveling.mp3
- Veskara_4maps.mp3
- Veskara_5highmaps.mp3
